# TODO: Document the boundary layer for web routes and external-service adapters.
