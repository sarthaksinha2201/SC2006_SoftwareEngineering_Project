# TODO: Document the helper that tracks and enforces a daily external-API usage cap.
