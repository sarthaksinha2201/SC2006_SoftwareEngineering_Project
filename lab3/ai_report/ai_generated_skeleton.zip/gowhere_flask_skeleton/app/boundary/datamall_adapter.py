# TODO: Document DataMall API access for carpark availability and paginated endpoints.
