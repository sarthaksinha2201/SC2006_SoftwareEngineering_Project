# TODO: Document the LLM adapter and its tool-call boundary.
