# TODO: Document the OneMap API adapter responsibilities: search, routing, and transit/driving routes.
