# TODO: Document Overpass query support for OpenStreetMap amenity data.
