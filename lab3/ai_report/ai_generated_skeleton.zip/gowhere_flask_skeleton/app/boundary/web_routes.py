# TODO: Document Flask route groups for Live, Lepak, Eat, and related detail pages.
