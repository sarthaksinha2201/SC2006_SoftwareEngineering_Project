# TODO: Document amenity scoring inputs and outputs.
