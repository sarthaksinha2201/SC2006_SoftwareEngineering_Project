# TODO: Document commute scoring and its use of the session's commute router.
