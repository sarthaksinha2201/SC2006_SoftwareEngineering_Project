# TODO: Document opening-hours parsing and status calculations.
