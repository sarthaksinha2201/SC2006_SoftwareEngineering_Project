# TODO: Document how place ratings and details are attached to Eat search results.
