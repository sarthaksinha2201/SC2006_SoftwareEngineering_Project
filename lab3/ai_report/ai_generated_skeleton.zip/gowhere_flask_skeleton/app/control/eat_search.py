# TODO: Document food-place search, browsing, filtering, opening status, routing, and parking-aware results.
