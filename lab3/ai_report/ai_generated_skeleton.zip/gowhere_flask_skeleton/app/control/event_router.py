# TODO: Document route lookup and batched routing for event destinations.
