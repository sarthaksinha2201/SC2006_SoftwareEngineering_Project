# TODO: Document greenery scoring inputs and outputs.
