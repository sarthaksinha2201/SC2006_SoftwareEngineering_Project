# TODO: Document housing-affordability scoring inputs and outputs.
