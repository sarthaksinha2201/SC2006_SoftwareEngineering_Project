# TODO: Document background event ingestion from external post sources.
