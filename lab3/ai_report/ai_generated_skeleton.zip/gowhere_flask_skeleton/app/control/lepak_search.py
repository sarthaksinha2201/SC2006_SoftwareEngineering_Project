# TODO: Document event search, filtering, sorting, routing, and parking-aware results.
