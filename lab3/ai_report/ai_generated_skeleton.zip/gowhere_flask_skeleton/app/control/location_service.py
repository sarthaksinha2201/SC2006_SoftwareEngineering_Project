# TODO: Document postal-code and venue location resolution, including offline fallback behavior.
