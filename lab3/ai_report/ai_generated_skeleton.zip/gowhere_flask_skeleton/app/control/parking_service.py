# TODO: Document nearby parking availability retrieval.
