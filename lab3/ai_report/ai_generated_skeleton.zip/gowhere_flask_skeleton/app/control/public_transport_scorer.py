# TODO: Document public-transport scoring inputs and outputs.
