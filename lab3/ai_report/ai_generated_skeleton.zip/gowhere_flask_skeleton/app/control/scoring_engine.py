# TODO: Document neighbourhood scoring orchestration, factor selection, and comparison.
