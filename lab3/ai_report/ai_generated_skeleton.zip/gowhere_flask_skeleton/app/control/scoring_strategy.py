# TODO: Document the shared scoring-strategy contract and expected strategy responsibilities.
