# TODO: Document the entity layer and its stores, records, and session state.
