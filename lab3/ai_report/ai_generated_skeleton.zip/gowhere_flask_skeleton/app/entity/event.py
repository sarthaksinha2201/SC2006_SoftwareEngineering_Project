# TODO: Document the event record fields represented by the design diagram.
