# TODO: Document event persistence, batch commits, cleanup, and channel checkpoints.
