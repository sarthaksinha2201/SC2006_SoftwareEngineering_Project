# TODO: Document a selected scoring factor's weight and options.
