# TODO: Document opening-hours data and open/closed/next-opening calculations.
