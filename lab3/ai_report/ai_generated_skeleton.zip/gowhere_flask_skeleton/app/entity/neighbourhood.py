# TODO: Document the neighbourhood record fields represented by the design diagram.
