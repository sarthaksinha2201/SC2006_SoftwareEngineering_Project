# TODO: Document the place record fields represented by the design diagram.
