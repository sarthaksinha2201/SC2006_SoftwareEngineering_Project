# TODO: Document place-data loading, metadata, and place lookup.
