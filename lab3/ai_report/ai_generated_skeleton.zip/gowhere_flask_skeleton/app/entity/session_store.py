# TODO: Document per-browser-session state lookup and identifier management.
