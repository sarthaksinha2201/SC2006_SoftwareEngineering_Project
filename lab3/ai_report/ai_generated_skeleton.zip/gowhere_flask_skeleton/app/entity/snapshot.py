# TODO: Document neighbourhood snapshot queries and metadata access.
