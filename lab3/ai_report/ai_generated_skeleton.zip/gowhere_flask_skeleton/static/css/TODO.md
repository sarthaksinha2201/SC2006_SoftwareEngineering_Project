# TODO: Add static assets for the application when they are designed.
