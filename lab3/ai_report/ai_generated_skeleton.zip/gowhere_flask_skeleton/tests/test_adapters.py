# TODO: Add isolated tests for external-service adapters using mocked responses.
