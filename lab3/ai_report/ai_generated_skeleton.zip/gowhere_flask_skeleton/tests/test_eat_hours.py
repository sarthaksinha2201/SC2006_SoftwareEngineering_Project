# TODO: Add tests for opening-hours parsing and status edge cases.
