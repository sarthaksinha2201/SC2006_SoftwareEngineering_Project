# TODO: Add tests for scoring strategy dispatch and neighbourhood comparisons.
