# TODO: Add tests for event/place stores, snapshots, and session state.
